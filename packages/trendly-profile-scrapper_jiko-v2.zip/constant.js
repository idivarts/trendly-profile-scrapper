const LeadAccountID = "jiko-windows-123"

const GENDERS = [
    "male",
    "female",
    "couple",
    "animal",
    "lgbtq",
    "gender-neutral",
];

const NICHES = [
    "Fashion / Beauty",
    "Lifestyle Vlogs",
    "Food",
    "Travel",
    "Fun / Comedy",
    "Fitness",
    "Gaming",
    "Motivational",
    "Finance",
    "Education",
    "Business",
    "Photography",
    "Cooking",
    "Art",
    "Music",
    "Dance",
    "Film / TV",
    "Sports",
    "Automobile",
    "Meme",
    "Quote Pages",
    "Parenting",
    "Health",
    "Tech",
    "Pets",
    "Dogs",
    "Cats",
    "NSFW",
    "Others",
];

const LOCATIONS = [
    "Mumbai",
    "Delhi",
    "Bengaluru",
    "Hyderabad",
    "Ahmedabad",
    "Chennai",
    "Kolkata",
    "Pune",
    "Surat",
    "Jaipur"
];
