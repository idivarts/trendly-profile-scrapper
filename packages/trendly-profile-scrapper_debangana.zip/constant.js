const LeadAccountID = "debangan-mukherjee-window"

const GENDERS = [
    "male",
    "female",
    "couple",
    "baby",
    "animal",
    "lgbtq",
    "gender-neutral",
];

const NICHES = [
    "Fashion / Beauty",
    "Lifestyle Vlogs",
    "Food",
    "Travel",
    "Fun / Meme",
    "Health",
    "Tech",
    "NSFW",
    "Others",
];

const LOCATIONS = [
    "Mumbai",
    "Delhi",
    "Bengaluru",
    "Hyderabad",
    "Ahmedabad",
    "Chennai",
    "Kolkata",
    "Pune",
    "Surat",
    "Jaipur"
];
